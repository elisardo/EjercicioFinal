package uax.poo.feedbackUD3.hotel;

public interface Impresion {
    public void ImprimirTodo();
}
